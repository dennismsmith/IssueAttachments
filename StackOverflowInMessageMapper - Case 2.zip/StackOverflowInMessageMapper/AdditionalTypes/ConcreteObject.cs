﻿namespace AdditionalTypes
{
	public class ConcreteObject : ICanBeCopied<ConcreteObject>
	{
		public ConcreteObject CopyMe()
		{
			// TODO: provide real implementation
			return null;
		}
	}
}
