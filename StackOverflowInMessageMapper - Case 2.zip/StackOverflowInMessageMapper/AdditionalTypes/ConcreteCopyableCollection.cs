﻿namespace AdditionalTypes
{
	public class ConcreteCopyableCollection : BaseCollection<ConcreteObject>, ICanBeCopied<ConcreteCopyableCollection>
	{
		public ConcreteCopyableCollection CopyMe()
		{
			// TODO: provide real implementation
			return new ConcreteCopyableCollection();
		}
	}
}
