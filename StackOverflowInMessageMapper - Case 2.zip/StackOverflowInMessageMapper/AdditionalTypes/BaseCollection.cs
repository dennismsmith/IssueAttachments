﻿using System.Collections;
using System.Collections.Generic;

namespace AdditionalTypes
{
	public abstract class BaseCollection<TItem> : IEnumerable<TItem>
	{	
		public IEnumerator<TItem> GetEnumerator()
		{
			return new List<TItem>.Enumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}
	}
}
