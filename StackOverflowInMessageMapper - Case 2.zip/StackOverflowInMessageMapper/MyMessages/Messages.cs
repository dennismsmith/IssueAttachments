using System;
using AdditionalTypes;

namespace MyMessages
{
	[Serializable]
	public class EventMessage : IMyEvent
	{
		public Guid EventId { get; set; }
		public DateTime? Time { get; set; }
		public TimeSpan Duration { get; set; }
		public ConcreteCopyableCollection Concrete { get; set; }
	}

	public interface IMyEvent
    {
        Guid EventId { get; set; }
        DateTime? Time { get; set; }
        TimeSpan Duration { get; set; }
		ConcreteCopyableCollection Concrete { get; set; }
    }
}
