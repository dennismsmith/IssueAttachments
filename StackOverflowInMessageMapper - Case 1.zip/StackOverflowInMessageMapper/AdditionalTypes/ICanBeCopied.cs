﻿namespace AdditionalTypes
{
	public interface ICanBeCopied<T>
	{
		T CopyMe();
	}
}
