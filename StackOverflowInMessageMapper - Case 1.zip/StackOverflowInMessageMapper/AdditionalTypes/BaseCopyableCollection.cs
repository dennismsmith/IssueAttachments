﻿using System.Collections;
using System.Collections.Generic;

namespace AdditionalTypes
{
	public abstract class BaseCopyableCollection<TCollection, TItem> : ICanBeCopied<TCollection>, IEnumerable<TItem> where TItem : ICanBeCopied<TItem>
	{
		public abstract TCollection CopyMe();
		
		public IEnumerator<TItem> GetEnumerator()
		{
			return new List<TItem>.Enumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}
	}
}
