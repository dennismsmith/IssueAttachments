﻿namespace AdditionalTypes
{
	public class ConcreteCopyableCollection : BaseCopyableCollection<ConcreteCopyableCollection, ConcreteObject>
	{
		public override ConcreteCopyableCollection CopyMe()
		{
			// TODO: provide real implementation
			return new ConcreteCopyableCollection();
		}
	}
}
